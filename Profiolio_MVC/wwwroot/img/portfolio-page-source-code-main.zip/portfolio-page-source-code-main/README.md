# Portfolio Page Source Code

This is the source code of a portfolio page generated with [Angular CLI](https://github.com/angular/angular-cli) version 15.0.0.  

Code is live at the [Monie Nguyen's Portfolio](https://monienguyen.github.io/)

## Development server

To run this project, you need to install [NodeJS](https://nodejs.org/en/).  

Run `npm install` for the first time running the project to install required packages.  

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Licence

Feel free to customise the source code to fit your needs. However, please **DO NOT** redistribute any content, images or videos used in this project without permission.  